<?php
// ── Viva Home GmbH – Kontaktformular SMTP Mail Handler ──
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: https://www.vivahome.de');
header('Access-Control-Allow-Methods: POST');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// PHPMailer laden (muss im Unterordner /phpmailer/ liegen)
require 'phpmailer/Exception.php';
require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';

// Konfiguration laden
require 'config.php';

// Eingaben bereinigen
function clean($str) {
    return htmlspecialchars(strip_tags(trim($str)), ENT_QUOTES, 'UTF-8');
}

$vorname   = clean($_POST['vorname']  ?? '');
$nachname  = clean($_POST['nachname'] ?? '');
$email     = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$betreff   = clean($_POST['betreff']  ?? 'Allgemeine Anfrage');
$nachricht = clean($_POST['nachricht'] ?? '');

if (!$vorname || !$nachname || !$email || !$nachricht) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Bitte alle Pflichtfelder ausfüllen.']);
    exit;
}

$name  = $vorname . ' ' . $nachname;
$datum = date('d.m.Y \u\m H:i \U\h\r');

function createMailer() {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = SMTP_HOST;
    $mail->SMTPAuth   = true;
    $mail->Username   = SMTP_USER;
    $mail->Password   = SMTP_PASS;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = SMTP_PORT;
    $mail->CharSet    = 'UTF-8';
    $mail->setFrom(SMTP_USER, 'Viva Home GmbH');
    return $mail;
}

$sent_intern = false;
$sent_kunde  = false;

// ── MAIL 1: Eingehende Anfrage an Viva Home GmbH ──
try {
    $mail = createMailer();
    $mail->addAddress('ve@vivahome.de', 'Viva Home GmbH');
    $mail->addReplyTo($_POST['email'], $name);
    $mail->Subject = '[Anfrage Website] ' . $betreff . ' – ' . $name;
    $mail->isHTML(false);
    $mail->Body = "Neue Kontaktanfrage über vivahome.de\n"
        . "=====================================\n"
        . "Datum:    {$datum}\n"
        . "Name:     {$name}\n"
        . "E-Mail:   {$_POST['email']}\n"
        . "Betreff:  {$betreff}\n\n"
        . "Nachricht:\n"
        . "----------\n"
        . "{$nachricht}\n\n"
        . "=====================================\n"
        . "Automatisch generiert von vivahome.de\n"
        . "Einfach auf Antworten klicken um den Kunden zu erreichen.";
    $mail->send();
    $sent_intern = true;
} catch (Exception $e) {
    error_log('VHG Mail intern Fehler: ' . $e->getMessage());
}

// ── MAIL 2: Bestätigung + Leistungsübersicht an Kunden ──
try {
    $mail = createMailer();
    $mail->addAddress($_POST['email'], $name);
    $mail->addReplyTo('ve@vivahome.de', 'Viva Home GmbH');
    $mail->Subject = 'Ihre Anfrage bei Viva Home GmbH – Wir melden uns!';
    $mail->isHTML(false);
    $mail->Body = "Guten Tag {$name},\n\n"
        . "vielen Dank für Ihre Anfrage! Wir haben Ihre Nachricht erhalten und\n"
        . "melden uns schnellstmöglich – in der Regel innerhalb von 24 Stunden.\n\n"
        . "Ihre Anfrage im Überblick:\n"
        . "--------------------------\n"
        . "Betreff:        {$betreff}\n"
        . "Nachricht:      {$nachricht}\n"
        . "Eingegangen am: {$datum}\n\n"
        . "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        . "UNSERE LEISTUNGEN FÜR SIE\n"
        . "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        . "■ IP-VIDEOÜBERWACHUNG (CCTV)\n"
        . "   Planung, Montage und Inbetriebnahme professioneller IP-Kamerasysteme.\n"
        . "   Innen- und Außenanlagen, hochauflösend, skalierbar, mit Fernzugriff.\n"
        . "   Geeignet für Gewerbe, Industrie, Logistik und öffentliche Bereiche.\n\n"
        . "■ EINBRUCHMELDEANLAGEN (EMA)\n"
        . "   Montage und Inbetriebnahme nach DIN VDE 0833.\n"
        . "   Bewegungsmelder, Magnetkontakte, Glasbruchsensoren –\n"
        . "   kabelgebunden und Funk. VdS-zertifizierte Systeme, inkl. Aufschaltung.\n\n"
        . "■ BRANDMELDEANLAGEN (BMA)\n"
        . "   Installation und Wartung nach DIN 14675.\n"
        . "   Von Rauchmeldern bis zur Feuerwehraufschaltung –\n"
        . "   normgerecht, zertifiziert und dokumentiert.\n\n"
        . "■ NETZWERKTECHNIK & LAN\n"
        . "   Strukturierte Verkabelung (Cat6/Cat7), Kabelzug,\n"
        . "   Glasfaserinstallation (LWL), Serverinstallation,\n"
        . "   Aufbau von Teilnetzen und WLAN-Infrastruktur.\n\n"
        . "■ IT-SUPPORT & SERVICE\n"
        . "   Vor-Ort-Service für EDV-Anlagen, Computerinstallation,\n"
        . "   Einrichtung von Netzwerkkomponenten und technischer Support\n"
        . "   für Gewerbe und Industrie.\n\n"
        . "■ SUBUNTERNEHMER-LEISTUNGEN\n"
        . "   Qualifizierte Elektriker-Zweierteams mit eigenem Fahrzeug und Werkzeug –\n"
        . "   flexibel abrufbar, kurzfristig verfügbar, bundesweit und europaweit.\n\n"
        . "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        . "KONTAKT\n"
        . "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        . "Viva Home GmbH\n"
        . "Volkhard Engelstädter – Geschäftsführer\n"
        . "An der Ringmauer 16 · 51492 Overath\n"
        . "Tel:   +49 172 88 48 478\n"
        . "Email: ve@vivahome.de\n"
        . "Web:   www.vivahome.de\n\n"
        . "HRB 95035 · Amtsgericht Köln · USt-IdNr.: DE285199745\n";
    $mail->send();
    $sent_kunde = true;
} catch (Exception $e) {
    error_log('VHG Mail Kunde Fehler: ' . $e->getMessage());
}

if ($sent_intern && $sent_kunde) {
    echo json_encode(['success' => true,
        'message' => 'Vielen Dank, ' . $vorname . '! Ihre Anfrage wurde gesendet. Sie erhalten gleich eine Bestätigung per E-Mail.']);
} elseif ($sent_intern) {
    echo json_encode(['success' => true,
        'message' => 'Anfrage erhalten! Die Bestätigungs-E-Mail konnte leider nicht zugestellt werden.']);
} else {
    http_response_code(500);
    echo json_encode(['success' => false,
        'message' => 'Fehler beim Senden. Bitte kontaktieren Sie uns direkt unter ve@vivahome.de oder +49 172 88 48 478.']);
}
?>
